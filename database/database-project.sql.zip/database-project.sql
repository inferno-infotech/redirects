-- phpMyAdmin SQL Dump
-- version 3.1.3.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 10, 2014 at 03:23 PM
-- Server version: 5.1.33
-- PHP Version: 5.2.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `samplereq`
--

-- --------------------------------------------------------

--
-- Table structure for table `buttons`
--

CREATE TABLE IF NOT EXISTS `buttons` (
  `user_id` int(11) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `button_name` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `caption` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `btn_code` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `buttons`
--

INSERT INTO `buttons` (`user_id`, `id`, `button_name`, `url`, `caption`, `image`, `btn_code`) VALUES
(2, 1, 'dc', 'vvffd', 'vfvdvd', 'image/certi.png', ''),
(2, 2, 'button2', 'www.gmail.com', 'very good', 'image/certi.png', ''),
(2, 3, 'button3', 'asscd', 'vdv', 'image/certi.png', ''),
(2, 4, 'Button4', 'adwad', 'seffewfw', '', ''),
(2, 5, 'Button5', 'wefwefewf', 'wewfefew', '', ''),
(2, 6, 'Button6', 'sdvvdsvds', 'vdvddv', 'image/certi.png', ''),
(2, 7, 'Button1', 'adwfdcvsd', 'vsvdsvd', 'image/certi.png', ''),
(2, 8, 'Button2', 'ssvdvsd', 'vdvdvd', 'image/certi.png', ''),
(2, 9, 'Button2', 'wefefew', 'eevvew', 'image/index_0.png', ''),
(2, 10, 'Button3', 'accecsa', 'cascsa', 'image/certi.png', ''),
(2, 11, 'button4', 'erfe', 'grere', 'image/certi.png', ''),
(2, 12, 'button5', 'fdvf', 'fvdfd', '', ''),
(2, 13, 'Tasnim', 'www.orkut.com', '1', 'image/certi.png', ''),
(2, 14, 'Asif', '', '10', 'image/certi.png', ''),
(2, 15, 'Mummu', '', '', 'image/certi.png', ''),
(2, 16, 'Mama', '', '14', '', ''),
(2, 17, 'New Button', '', '15', 'image/certi.png', ''),
(2, 18, 'Mimi', '', '1', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE IF NOT EXISTS `schedule` (
  `button_id` int(11) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `day` varchar(255) NOT NULL,
  `start_time` varchar(255) NOT NULL,
  `end_time` varchar(255) NOT NULL,
  `message` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `btn_code` varchar(255) NOT NULL,
  `url_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=28 ;

--
-- Dumping data for table `schedule`
--

INSERT INTO `schedule` (`button_id`, `id`, `day`, `start_time`, `end_time`, `message`, `url`, `btn_code`, `url_id`) VALUES
(5, 1, 'Sunday', '1:00', '1:00', 'dsvsd', 'www.gmail.com', '', 0),
(6, 2, 'Sunday', '5:00', '1:00', 'ecv', 'www.gmail.com', '', 0),
(6, 3, 'Sunday', '5:00', '1:00', 'ecv', 'www.gmail.com', '', 0),
(5, 4, 'Sunday', '4:00', '1:00', 'sevvr', 'www.gmail.com', '', 0),
(6, 5, 'Monday', '1:00', '1:00', 'sdvs', 'www.gmail.com', '', 0),
(5, 6, 'Sunday', '1:00', '1:00', 'r3w', 'www.gmail.com', '', 0),
(6, 7, 'Sunday', '1:00', '1:00', 'ewfgr', 'www.gmail.com', '', 0),
(6, 8, 'Sunday', '1:00', '1:00', 'ewfgr', 'www.gmail.com', '', 0),
(6, 9, 'Monday', '1:00', '1:00', 'ewffw', 'www.gmail.com', '', 0),
(6, 10, 'Monday', '1:00', '1:00', 'ewffw', 'www.gmail.com', '', 0),
(17, 11, 'Sunday', '1:00', '1:00', 'very good', 'www.gmail.com', '', 0),
(17, 12, 'Sunday', '1:00', '1:00', 'very good', 'www.gmail.com', '', 0),
(16, 13, 'Sunday', '1:00', '1:00', 'asdsdvd', 'www.gmail.com', '', 0),
(17, 14, 'Sunday', '1:00', '1:00', 'avsvsv', 'www.gmail.com', '', 0),
(17, 15, 'Sunday', '1:00', '1:00', 'ssvv', 'www.gmail.com', '', 0),
(1, 17, 'Sunday', '1:00', '1:00', 'd s vsd ', 'www.gmail.com', '', 0),
(4, 19, 'Sunday', '1:00', '5:00', 'cdsvds', 'www.gmail.com', '', 0),
(1, 23, 'Sunday', '1:00', '1:00', 'Very bad', 'www.gmail.com', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `url`
--

CREATE TABLE IF NOT EXISTS `url` (
  `iduser` int(11) NOT NULL,
  `idbutton` int(11) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `caption` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `url`
--

INSERT INTO `url` (`iduser`, `idbutton`, `id`, `url`, `caption`) VALUES
(2, 1, 1, 'www.gmail.com', 'good'),
(2, 14, 11, 'www.gmail.com', 'very very good'),
(2, 2, 4, 'new url', 'more good'),
(2, 18, 19, 'www.yahoo.com', 'bad'),
(2, 18, 18, 'www.gmail.com', 'good'),
(2, 17, 16, 'wadca', 'cac'),
(2, 17, 17, 'eveewfewewvf', 'vevvr');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Alias` varchar(255) NOT NULL,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `linkid` varchar(255) NOT NULL,
  `note` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `admin` int(11) NOT NULL,
  `time_difference` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `Alias`, `fname`, `lname`, `email`, `phone`, `linkid`, `note`, `status`, `password`, `admin`, `time_difference`) VALUES
(2, 'Tasnim', 'Tasnim123', 'Khan', 'tasnim@gmail.com', '9889262973', 'www.gmail.com', 'very good', 'Enable', '9889262973', 0, 0),
(14, 'imran4', 'imm', 'khn', 'im@gmail.com', '9889262973', 'www.hardcode.com', 'very awesome', 'Enable', '', 0, 0),
(15, 'Imran4', 'Immmm', 'khan234', 'im@gmail.com', '9935461320', 'www.gmail.com', 'very bad', 'Enable', '', 0, 0),
(9, 'Imran1123', 'Imran1234', 'Khan1', 'imran@gmail.com', '9889262973', 'www.gmail.com', 'very good', 'Enable', '', 0, 0);
