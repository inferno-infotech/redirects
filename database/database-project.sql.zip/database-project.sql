-- phpMyAdmin SQL Dump
-- version 3.1.3.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 10, 2014 at 03:18 AM
-- Server version: 5.1.33
-- PHP Version: 5.2.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `samplereq`
--

-- --------------------------------------------------------

--
-- Table structure for table `sample`
--

CREATE TABLE IF NOT EXISTS `sample` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Alias` varchar(255) NOT NULL,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `linkid` varchar(255) NOT NULL,
  `note` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `sample`
--

INSERT INTO `sample` (`id`, `Alias`, `fname`, `lname`, `email`, `phone`, `linkid`, `note`, `status`) VALUES
(2, 'Tasnim', 'Tasnim123', 'Khan', 'tasnim@gmail.com', '9889262973', 'www.gmail.com', 'very good', 'Enable'),
(14, 'imran4', 'imm', 'khn', 'im@gmail.com', '9889262973', 'www.hardcode.com', 'very awesome', 'Enable'),
(15, 'Imran4', 'Immmm', 'khan234', 'im@gmail.com', '9935461320', 'www.gmail.com', 'very bad', 'Enable'),
(9, 'Imran', 'Imran123', 'Khan1', 'imran@gmail.com', '9889262973', 'www.gmail.com', 'very good', 'Enable'),
(12, 'Imran2', 'Imm', 'Khn', 'imran@gmail.com', '9450090786', 'www.google.com', 'very good', 'Enable'),
(13, 'Imran3', 'Immm', 'khan', 'immkhan@gmail.com', '9450090786', 'www.go.com', 'very bad', 'Enable');

-- --------------------------------------------------------

--
-- Table structure for table `sample1`
--

CREATE TABLE IF NOT EXISTS `sample1` (
  `id1` int(11) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `caption` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `sample1`
--

INSERT INTO `sample1` (`id1`, `id`, `Name`, `url`, `caption`, `image`) VALUES
(2, 1, 'dc', 'vvffd', 'vfvdvd', 'image/certi.png'),
(2, 2, 'button2', 'www.gmail.com', 'very good', 'image/certi.png'),
(2, 3, 'button3', 'asscd', 'vdv', 'image/certi.png'),
(2, 4, 'Button4', 'adwad', 'seffewfw', ''),
(2, 5, 'Button5', 'wefwefewf', 'wewfefew', ''),
(2, 6, 'Button6', 'sdvvdsvds', 'vdvddv', 'image/certi.png'),
(2, 7, 'Button1', 'adwfdcvsd', 'vsvdsvd', 'image/certi.png'),
(2, 8, 'Button2', 'ssvdvsd', 'vdvdvd', 'image/certi.png'),
(2, 9, 'Button2', 'wefefew', 'eevvew', 'image/index_0.png'),
(2, 10, 'Button3', 'accecsa', 'cascsa', 'image/certi.png'),
(2, 11, 'button4', 'erfe', 'grere', 'image/certi.png'),
(2, 12, 'button5', 'fdvf', 'fvdfd', ''),
(2, 13, 'Tasnim', 'www.orkut.com', '1', 'image/certi.png'),
(2, 14, 'Asif', '', '10', 'image/certi.png'),
(2, 15, 'Mummu', '', '', 'image/certi.png'),
(2, 16, 'Mama', '', '14', ''),
(2, 17, 'New Button', '', '15', 'image/certi.png');

-- --------------------------------------------------------

--
-- Table structure for table `sample2`
--

CREATE TABLE IF NOT EXISTS `sample2` (
  `idbutton` int(11) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `day` varchar(255) NOT NULL,
  `start_time` varchar(255) NOT NULL,
  `end_time` varchar(255) NOT NULL,
  `message` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `sample2`
--

INSERT INTO `sample2` (`idbutton`, `id`, `day`, `start_time`, `end_time`, `message`, `url`) VALUES
(5, 1, 'Sunday', '1:00', '1:00', 'dsvsd', 'www.gmail.com'),
(6, 2, 'Sunday', '5:00', '1:00', 'ecv', 'www.gmail.com'),
(6, 3, 'Sunday', '5:00', '1:00', 'ecv', 'www.gmail.com'),
(5, 4, 'Sunday', '4:00', '1:00', 'sevvr', 'www.gmail.com'),
(6, 5, 'Monday', '1:00', '1:00', 'sdvs', 'www.gmail.com'),
(5, 6, 'Sunday', '1:00', '1:00', 'r3w', 'www.gmail.com'),
(6, 7, 'Sunday', '1:00', '1:00', 'ewfgr', 'www.gmail.com'),
(6, 8, 'Sunday', '1:00', '1:00', 'ewfgr', 'www.gmail.com'),
(6, 9, 'Monday', '1:00', '1:00', 'ewffw', 'www.gmail.com'),
(6, 10, 'Monday', '1:00', '1:00', 'ewffw', 'www.gmail.com'),
(17, 11, 'Sunday', '1:00', '1:00', 'very good', 'www.gmail.com'),
(17, 12, 'Sunday', '1:00', '1:00', 'very good', 'www.gmail.com'),
(16, 13, 'Sunday', '1:00', '1:00', 'asdsdvd', 'www.gmail.com'),
(17, 14, 'Sunday', '1:00', '1:00', 'avsvsv', 'www.gmail.com'),
(17, 15, 'Sunday', '1:00', '1:00', 'ssvv', 'www.gmail.com'),
(1, 17, 'Sunday', '1:00', '1:00', 'd s vsd ', 'www.gmail.com'),
(4, 19, 'Sunday', '1:00', '5:00', 'cdsvds', 'www.gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `sample3`
--

CREATE TABLE IF NOT EXISTS `sample3` (
  `iduser` int(11) NOT NULL,
  `idbutton` int(11) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `caption` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `sample3`
--

INSERT INTO `sample3` (`iduser`, `idbutton`, `id`, `url`, `caption`) VALUES
(2, 1, 1, 'www.gmail.com', 'good'),
(2, 14, 11, 'www.gmail.com', 'very very good'),
(2, 2, 4, 'new url', 'more good'),
(2, 1, 14, 'very good', 'hahahah'),
(2, 1, 15, 'very good1', 'hahahah'),
(2, 17, 16, 'wadca', 'cac'),
(2, 17, 17, 'eveewfewewvf', 'vevvr');
